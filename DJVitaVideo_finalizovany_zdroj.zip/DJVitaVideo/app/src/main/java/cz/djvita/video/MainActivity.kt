package cz.djvita.video

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import android.view.ViewGroup
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.os.Environment
import android.provider.MediaStore
import android.content.ContentValues
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.io.FileInputStream

@UnstableApi
class MainActivity : Activity() {
    private var photo1: Uri? = null
    private var photo2: Uri? = null
    private var ownVideo: Uri? = null
    private var audio: Uri? = null
    private lateinit var status: TextView
    private lateinit var selectedFiles: TextView
    private lateinit var duration: Spinner
    private lateinit var style: Spinner
    private lateinit var singer: Spinner
    private lateinit var lyrics: EditText
    private lateinit var trimStart: EditText
    private lateinit var trimEnd: EditText

    companion object {
        private const val PICK_PHOTO_1 = 1
        private const val PICK_PHOTO_2 = 2
        private const val PICK_VIDEO = 3
        private const val PICK_AUDIO = 4
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF5F5F5.toInt())
        }

        fun heading(text: String) {
            root.addView(TextView(this).apply {
                this.text = text
                textSize = 19f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF202020.toInt())
                setPadding(0, 18, 0, 6)
            })
        }

        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                textSize = 16f
                setOnClickListener { action() }
            }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        fun spinner(items: List<String>): Spinner {
            return Spinner(this).also {
                it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
                root.addView(it)
            }
        }

        root.addView(TextView(this).apply {
            text = "DJVíťa Video"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF202020.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Příprava hudebního videoklipu z vašich podkladů"
            textSize = 16f
        })

        heading("1. Fotografie a video")
        button("Vybrat moji fotografii") { pick("image/*", PICK_PHOTO_1) }
        button("Vybrat druhou fotografii") { pick("image/*", PICK_PHOTO_2) }
        button("Vybrat vlastní video (volitelné)") { pick("video/*", PICK_VIDEO) }

        heading("2. Hudba")
        button("Vybrat písničku") { pick("audio/*", PICK_AUDIO) }

        heading("3. Délka výsledného klipu")
        duration = spinner(listOf("10 sekund", "20 sekund", "30 sekund", "1 minuta", "Celá skladba"))

        heading("4. Vzhled videa")
        style = spinner(listOf("Realistický", "Kreslený"))

        heading("5. Kdo zpívá?")
        singer = spinner(listOf(
            "Automaticky – rozpoznat hlasy (AI zatím nepřipojena)",
            "Mužský zpěv",
            "Ženský zpěv",
            "Muž a žena – duet"
        ))

        heading("6. Text písně nebo námět scén (volitelné)")
        lyrics = EditText(this).apply {
            hint = "Vlož text písně nebo popiš scény, které chceš ve videu…"
            minLines = 3
            gravity = android.view.Gravity.TOP
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(lyrics, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        heading("7. Ořez skladby (sekundy)")
        trimStart = EditText(this).apply {
            hint = "Začátek, např. 0"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        root.addView(trimStart)
        trimEnd = EditText(this).apply {
            hint = "Konec, prázdné = konec skladby"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        root.addView(trimEnd)

        heading("Vybrané soubory")
        selectedFiles = TextView(this).apply {
            text = "Fotografie 1: nevybrána\nFotografie 2: nevybrána\nVideo: nevybráno\nHudba: nevybrána"
            textSize = 14f
            setPadding(0, 8, 0, 12)
        }
        root.addView(selectedFiles)

        heading("Stav podkladů")
        status = TextView(this).apply {
            text = "Zatím nejsou vybrané žádné soubory."
            textSize = 15f
            setPadding(0, 8, 0, 16)
        }
        root.addView(status)

        button("Zkontrolovat a připravit nastavení klipu") { validateAndSummarize() }
        button("Navrhnout scény podle textu písně") { showScenePlan() }
        button("VYTVOŘIT A ULOŽIT VIDEO MP4") { exportVideo() }

        root.addView(TextView(this).apply {
            text = "\nDŮLEŽITÉ: MP4 export z fotografií nebo videa s hudbou je dostupný přes tlačítko VYTVOŘIT VIDEO. " +
                "AI synchronizace rtů, automatické rozpoznání hlasů a generování scén podle textu " +
                "vyžadují připojení a otestování externí AI služby. Nic placeného se nespustí bez " +
                "samostatného potvrzení uživatele."
            textSize = 14f
            setTextColor(0xFF6A3500.toInt())
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun pick(type: String, code: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            this.type = type
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, code)
    }

    @Deprecated("Kept for compatibility with simple Android project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Some document providers do not grant persistable permissions.
        }
        when (requestCode) {
            PICK_PHOTO_1 -> photo1 = uri
            PICK_PHOTO_2 -> photo2 = uri
            PICK_VIDEO -> ownVideo = uri
            PICK_AUDIO -> audio = uri
        }
        refreshSelectedFiles()
        updateStatus("Soubor byl vybrán.")
    }

    private fun refreshSelectedFiles() {
        selectedFiles.text = "Fotografie 1: ${photo1?.let { fileName(it) } ?: "nevybrána"}\n" +
            "Fotografie 2: ${photo2?.let { fileName(it) } ?: "nevybrána"}\n" +
            "Video: ${ownVideo?.let { fileName(it) } ?: "nevybráno"}\n" +
            "Hudba: ${audio?.let { fileName(it) } ?: "nevybrána"}"
    }

    private fun mediaDurationSeconds(uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000L
        } catch (_: Exception) {
            0L
        } finally {
            try { retriever.release() } catch (_: Exception) { }
        }
    }

    private fun fileName(uri: Uri): String {
        var result = uri.lastPathSegment ?: "vybraný soubor"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) result = cursor.getString(index) ?: result
        }
        return result
    }

    private fun showScenePlan() {
        val text = lyrics.text.toString().lowercase()
        val audioDuration = audio?.let { mediaDurationSeconds(it) } ?: 0L
        val trimFrom = trimStart.text.toString().toLongOrNull() ?: 0L
        val trimTo = trimEnd.text.toString().toLongOrNull() ?: audioDuration
        val availableDuration = if (audioDuration > 0L) (minOf(trimTo, audioDuration) - trimFrom).coerceAtLeast(1L) else 120L
        val chosenDuration = when (duration.selectedItemPosition) {
            0 -> 10L
            1 -> 20L
            2 -> 30L
            3 -> 60L
            else -> availableDuration
        }.coerceAtMost(availableDuration).toInt()
        val scenes = mutableListOf<String>()
        fun addIfFound(words: List<String>, scene: String) {
            if (words.any { text.contains(it) }) scenes.add(scene)
        }
        addIfFound(listOf("řeka", "voda", "moře", "déšť", "rain", "sea", "river"),
            "Voda, řeka nebo mořské pobřeží – klidný široký záběr.")
        addIfFound(listOf("les", "strom", "louka", "květ", "forest", "flower", "field"),
            "Zelená krajina, les nebo rozkvetlá louka.")
        addIfFound(listOf("noc", "hvězd", "měsíc", "night", "star", "moon"),
            "Noční obloha s měsícem a hvězdami.")
        addIfFound(listOf("město", "ulic", "světla", "city", "street", "light"),
            "Večerní město a světla ulic.")
        addIfFound(listOf("lás", "srdc", "miluj", "love", "heart", "kiss"),
            "Romantický záběr dvojice při západu slunce.")
        addIfFound(listOf("tan", "párty", "party", "dance"),
            "Dynamická taneční scéna v rytmu hudby.")
        if (scenes.isEmpty()) {
            scenes.add("Úvodní detail obou fotografií s pozvolným přiblížením.")
            scenes.add("Střídání portrétů podle slok a refrénu.")
            scenes.add("Společný závěrečný záběr s jemným oddálením.")
        } else {
            scenes.add(0, "Úvodní záběr: postupné odhalení obou postav.")
            scenes.add("Závěr: společný záběr a pozvolné ztmavení.")
        }
        val slot = (chosenDuration / scenes.size).coerceAtLeast(3)
        val plan = scenes.mapIndexed { index, scene ->
            val from = index * slot
            val to = if (index == scenes.lastIndex) chosenDuration else (from + slot)
            "${from}s–${to}s: $scene"
        }.joinToString("\n")
        updateStatus("NÁVRH SCÉN (orientační, podle klíčových slov; nejde o AI generování):\n$plan")
    }

    private fun exportVideo() {
        if (audio == null) { updateStatus("Nejdřív vyber písničku."); return }
        if (photo1 == null && photo2 == null && ownVideo == null) { updateStatus("Vyber alespoň jednu fotografii nebo vlastní video."); return }
        val audioLength = mediaDurationSeconds(audio!!)
        if (audioLength <= 0L) { updateStatus("Nepodařilo se zjistit délku hudby."); return }
        val startSec = trimStart.text.toString().toLongOrNull() ?: 0L
        val endSec = trimEnd.text.toString().toLongOrNull() ?: audioLength
        if (startSec < 0 || endSec <= startSec || startSec >= audioLength || endSec > audioLength) { updateStatus("Zkontroluj ořez skladby. Konec musí být za začátkem a v délce skladby."); return }
        val wanted = when (duration.selectedItemPosition) { 0 -> 10L; 1 -> 20L; 2 -> 30L; 3 -> 60L; else -> endSec - startSec }
        val requestedSeconds = minOf(wanted, endSec - startSec)
        val sourceVideoLength = ownVideo?.let { mediaDurationSeconds(it) } ?: Long.MAX_VALUE
        if (ownVideo != null && sourceVideoLength <= 0L) {
            updateStatus("Nepodařilo se zjistit délku vybraného videa.")
            return
        }
        val clipSeconds = minOf(requestedSeconds, sourceVideoLength)
        if (clipSeconds <= 0L) {
            updateStatus("Výsledný klip by měl nulovou délku. Zkontroluj zdrojové video a ořez.")
            return
        }
        val videoItems = mutableListOf<EditedMediaItem>()
        if (ownVideo != null) {
            val useMs = clipSeconds * 1000L
            val videoMedia = MediaItem.Builder().setUri(ownVideo!!).setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(0).setEndPositionMs(useMs).build()).build()
            videoItems.add(EditedMediaItem.Builder(videoMedia).setRemoveAudio(true).build())
        } else {
            val photos = listOfNotNull(photo1, photo2)
            val eachMs = (clipSeconds * 1000L / photos.size).coerceAtLeast(1000L)
            photos.forEach { uri ->
                val image = MediaItem.Builder().setUri(uri).setImageDurationMs(eachMs).build()
                videoItems.add(EditedMediaItem.Builder(image).setFrameRate(30).build())
            }
        }
        val audioMedia = MediaItem.Builder().setUri(audio!!).setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startSec * 1000L).setEndPositionMs((startSec + clipSeconds) * 1000L).build()).build()
        val audioEdited = EditedMediaItem.Builder(audioMedia).build()
        val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)
        val audioSequence = EditedMediaItemSequence.withAudioFrom(listOf(audioEdited))
        val composition = Composition.Builder(videoSequence, arrayOf(audioSequence)).build()
        val output = File(cacheDir, "djvita_${System.currentTimeMillis()}.mp4")
        status.text = "Vytvářím MP4… Nezavírej aplikaci."
        val transformer = Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    try {
                        val values = ContentValues().apply {
                            put(MediaStore.Video.Media.DISPLAY_NAME, "DJVitaVideo_${System.currentTimeMillis()}.mp4")
                            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/DJVitaVideo")
                            put(MediaStore.Video.Media.IS_PENDING, 1)
                        }
                        val dest = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: error("Nelze vytvořit soubor v Galerii.")
                        try {
                            contentResolver.openOutputStream(dest)?.use { out -> FileInputStream(output).use { it.copyTo(out) } } ?: error("Nelze zapsat video do Galerie.")
                            val publish = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                            contentResolver.update(dest, publish, null, null)
                        } catch (e: Exception) {
                            contentResolver.delete(dest, null, null)
                            throw e
                        }
                        output.delete()
                        updateStatus("HOTOVO! MP4 je uložené v Galerii → Alba → DJVitaVideo.")
                    } catch (e: Exception) { updateStatus("Export je hotový, ale uložení do Galerie selhalo: ${e.message}. Dočasný soubor: ${output.absolutePath}") }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    updateStatus("Export se nepodařil: ${exportException.message ?: "chyba formátu nebo kodéru"}")
                    output.delete()
                }
            }).build()
        try { transformer.start(composition, output.absolutePath) } catch (e: Exception) { updateStatus("Export nelze spustit: ${e.message}"); output.delete() }
    }

    private fun validateAndSummarize() {
        if (audio == null) {
            updateStatus("Chybí písnička. Nejdřív vyber zvukovou skladbu.")
            return
        }
        if (photo1 == null && photo2 == null && ownVideo == null) {
            updateStatus("Vyber alespoň jednu fotografii nebo vlastní video.")
            return
        }
        val start = trimStart.text.toString().toLongOrNull() ?: 0L
        val end = trimEnd.text.toString().toLongOrNull()
        if (start < 0 || (end != null && end <= start)) {
            updateStatus("Ořez není správně: konec musí být větší než začátek.")
            return
        }
        val summary = buildString {
            append("Podklady jsou vybrané.\n")
            append("Fotografie 1: ${if (photo1 != null) "ano" else "ne"}\n")
            append("Fotografie 2: ${if (photo2 != null) "ano" else "ne"}\n")
            append("Vlastní video: ${if (ownVideo != null) "ano" else "ne"}\n")
            append("Hudba: ano\n")
            append("Délka cílového klipu: ${duration.selectedItem}\n")
            append("Styl: ${style.selectedItem}\n")
            append("Zpěv: ${singer.selectedItem}\n")
            append("Ořez skladby: od $start s do ${end?.let { "$it s" } ?: "konce"}\n")
            append("Text/námět: ${if (lyrics.text.isBlank()) "nezadán" else "zadán"}\n\n")
            append("Kontrola výběru proběhla. Stiskni VYTVOŘIT A ULOŽIT VIDEO MP4.")
        }
        updateStatus(summary)
    }

    private fun updateStatus(message: String) {
        status.text = message
    }
}
